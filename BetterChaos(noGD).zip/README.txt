Installation Instructions:
1.  Back up your DATA file, found under "steamapps/common/Dark Souls Prepare to Die Edition"
2.  Download HotPocketRemix's modding tool, drag the program into your DATA folder, then run the program
Link to HotPocketRemix's Tool:
https://github.com/HotPocketRemix/UnpackDarkSoulsForModding/tree/master/dist
3.  It is recommended that you back up your saves as well which should be in "My Documents/NBGI/DarkSouls"
4.  Move the folders in this zip file into your DATA folder.  This will prompt you to replace four files, all of which you should accept.
5.  Your game is modded! If you have any questions, feel free to pm /u/CoelyPuffs on Reddit